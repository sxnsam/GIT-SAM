# ***************************************************************************************
# Script: pull_from_repository
#
# This script will get Integration artifacts from Repository and save the artifacts
#  in a local directory for later deployment.
#
# Oracle 
# Created by:   Richard Poon
# Created date: 5/13/2019
# Updated date: 9/20/2019
#
# Mandatory parameters:
# - GIT_INSTALL_LOC        : Git Installed location
# - LOCAL_REPOSITORYR_ROOT : Root Local Repo location
# - REMOTE_REPOSITORY      : Remote Bitbucket Repository
# - BITBUCKET_USERNAME     : Bitbucket Username
# - BITBUCKET_EMAILR       : Bitbucket user email
#
# Disclaimer:
#
# You expressly understand and agree that your use of the utilities is at your sole risk and that 
# the utilities are provided on an "as is" and "as available" basis. Oracle expressly disclaims 
# all warranties of any kind, whether express or implied, including, but not limited to, the implied 
# warranties of merchantability, fitness for a particular purpose and non-infringement. 
# Any material downloaded or otherwise obtained through this delivery is done at your own discretion 
# and risk and you will be solely responsible for any damage to your computer system or loss of data 
# that results from the download of any such material.
#
#
# ****************************************************************************************
NUM_ARG=$#

if [[ $NUM_ARG -lt 5 ]]
then
	echo "[ERROR] Missing mandatory arguments: "`basename "$0"`" <GIT_INSTALL_PATH> <LOCAL_REPO> <REMOTE_REPO> <BITBUCKET_USERNAME> <BITBUCKET_USER_EMAIL> "
	exit 1
fi

CURRENT_DIR=$(pwd)
WORK_DIR=$CURRENT_DIR
connection_json_dir=$WORK_DIR/../04_deploy_integrations/config

git_install_loc=${1}
local_repo_root=${2}
remote_repo=${3}
bitbucket_username=${4}
bitbucket_email=${5}
connection_json_loc=${6:-$connection_json_dir}
working_dir=${7:-$WORK_DIR}

export PATH=${git_install_loc}/bin:$PATH

default="test"

echo "Root location of Local Repo is $local_repo_root"
echo "Remote Repo is $remote_repo"

if [ -z "$remote_repo" ]
then
    printf "Cannot continue without remote repostiroy!\n\n"
    exit
fi

IAR_temp_location="$WORK_DIR/IAR_location"

echo "IAR_temp_location = " $IAR_temp_location

if [ -d "$IAR_temp_location" ]; then
    echo "IAR temp Repository exists .. removing it .. "
    rm -rf $IAR_temp_location
fi
mkdir -p $IAR_temp_location

if [ -d "$local_repo_root/temp_repo" ]; then
    echo "temp Repository exists .. removing it .. "
    rm -rf $local_repo_root/temp_repo
fi

echo "1 - creating temp Repo directory .."
mkdir -p $local_repo_root/temp_repo

echo "2 - go to "  $local_repo_root/temp_repo
cd $local_repo_root/temp_repo

echo "3 - run git config for Bitbucket user.name .."
git config --global user.name $bitbucket_username

echo "4 - run git config for user.email .."
git config --global user.email $bitbucket_email

echo "5 - git clone the Remote repo .."
git clone $remote_repo

localTempRepo=($local_repo_root/temp_repo/*)
echo "local Temp Repo = " $localTempRepo

echo "6 - go to "  $localTempRepo
cd $localTempRepo

echo "7 - copying artifacts to temporary IAR Location" $IAR_temp_location
cp *.json $connection_json_dir
cp *.iar  $IAR_temp_location

echo "Cleanup temp Local Repository:  " $local_repo_root/temp_repo
rm -rf $local_repo_root/temp_repo

